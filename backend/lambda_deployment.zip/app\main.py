from fastapi import FastAPI
from app.routers import equipments, hospitals, technicians, workorders, auth, reportinglines, maintenanceflags, users, servicereports
from fastapi.middleware.cors import CORSMiddleware
from app.config import settings

app = FastAPI(
    version="0.1.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[settings.frontend_origin],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"]
)

app.include_router(equipments.router)
app.include_router(hospitals.router)
app.include_router(technicians.router)
app.include_router(workorders.router)
app.include_router(users.router)
app.include_router(servicereports.router)
app.include_router(auth.router)
app.include_router(reportinglines.router)
app.include_router(maintenanceflags.router)

@app.get("/health", tags=["health"])
async def health_check() -> dict[str, str]:
    return {"status": "ok"}
